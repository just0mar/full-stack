@extends('layouts.layout')


@section('title')
    Welcome Page
    
@endsection
@section('content')
<h1>Welcome</h1> 
@endsection